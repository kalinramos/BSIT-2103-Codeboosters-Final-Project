package Silayan;
enum Style {
  Adventure, Culture, Relaxation, None; 
}
enum Expense {
  Budget, Midrange, Highend, None;
}
class User{
  Style style;
  Expense expense;
  
  User(int style, int budget){
    this.expense = expense(budget);
    this.style = style(style);
  }
  Expense expense(int budget) {
    switch(budget) {
      case 1 -> {return this.expense = Expense.Budget;}
      case 2 -> {return this.expense = Expense.Midrange;}
      case 3 -> {return this.expense = Expense.Highend;}
      default -> {return this.expense = Expense.None;}
    }
  }
  Style style(int style){
    switch(style) {
      case 1 -> {return this.style = Style.Adventure;}
      case 2 -> {return this.style = Style.Culture;}
      case 3 -> {return this.style = Style.Relaxation;}
      default -> {return this.style = Style.None;}
    }
  }

  Style getStyle(){
    return this.style;
  }

  

}
