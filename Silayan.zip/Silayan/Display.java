package Silayan;
public class Display extends  {
  void suggestingDestinations(){
    if (style == Style.Adventure && expense == Expense.Budget) {
      System.out.println();
    }
  }
}