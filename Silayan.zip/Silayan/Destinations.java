package Silayan;
import java.util.List;
import java.util.ArrayList;

enum Relaxation{
  MuaraBeach, BruneiBay;
}
enum Adventure{
  UluTemburongNationalPark, BudaNationalPark;
}
enum Culture{
  KampongAyer, RoyalRegiliaMuseum;
}
class Yo {
  Relaxation relaxation; 
  Adventure adventure;
  Culture culture;
  String description;

}
class RDestination extends Yo {
    public RDestination(Relaxation relaxation, String description){
      super.relaxation = relaxation;
      super.description = description;
    }
    public Relaxation getRelaxation(){
      return relaxation;
    }
    @Override
    public String toString(){
      return relaxation.name() + "\nDescription: " + description;
    }
  }
class ADestination extends Yo{
   
    private String description;
    public ADestination(Adventure adventure, String description){
      super.adventure = adventure;
      super.description = description;
    }
    public Adventure getAdventure(){
      return adventure;
    }
    @Override
    public String toString(){
      return adventure.name() + "\nDescription: " + description;
    }
  }
class CDestination extends Yo{
    private String description;
    public CDestination(Culture culture, String description){
      this.culture = culture;
      this.description = description;
    }
    public Culture getCulture(){
      return culture;
    }
    @Override
    public String toString(){
      return culture.name() + "\nDescription: " + description;
    }
  }
public class Destinations {
  public final List<RDestination> RList = new ArrayList<>();
  public final List<ADestination> AList = new ArrayList<>();
  public final List<CDestination> CList = new ArrayList<>();
  public Destinations(){
      RList.add(new RDestination(Relaxation.BruneiBay, "Brunei Bay is on the northwestern coast of Borneo island, in Brunei and Malaysia."));
      RList.add(new RDestination(Relaxation.MuaraBeach, "Muara Beach is a beach in Muara, Mukim Serasa, Brunei-Muara District, Brunei."));
      AList.add(new ADestination(Adventure.BudaNationalPark, "Gunung Buda National Park is a national park located in Limbang Division, Sarawak, Malaysia."));
      AList.add(new ADestination(Adventure.UluTemburongNationalPark,"Ulu Temburong National Park is the first national park to be established in Brunei, protected since 1991."));
      CList.add(new CDestination(Culture.KampongAyer, "Kampung Ayer is a prominent traditional settlement in Bandar Seri Begawan, the capital of Brunei."));
      CList.add(new CDestination(Culture.RoyalRegiliaMuseum, "The Royal Regalia Museum is a museum located in the heart of Bandar Seri Begawan, the capital of Brunei."));
    }
  public List<RDestination> getRelaxationList(){
    return RList;
  }
  public List<ADestination> getAdventureList() {
    return AList;
  }
  public List<CDestination> getCulturalList() {
    return CList;
  }
}



