package Silayan;
import java.util.Scanner;

public class Here {

  static Scanner scanner = new Scanner(System.in);
  static Destinations destination = new Destinations();

  public static void main(String args[]) {
    
    System.out.println("\nTravel style: ");
    System.out.println("1. Adventure");
    System.out.println("2. Cultural Immersion");
    System.out.println("3. Relaxation");
    System.out.println("4. None\n");

    System.out.print("Enter choice (1-4): ");
    int style = scanner.nextInt();

    System.out.println("\nBudget: ");
    System.out.println("1. ");
    System.out.println("2. Cultural Immersion");
    System.out.println("3. Relaxation");
    System.out.println("4. None\n");
    System.out.print("Enter choice (1-3): ");
    int budget = scanner.nextInt();
    
    for(ADestination si: destination.getAdventureList() ){
      System.out.println(si);
    }
    for(RDestination si: destination.getRelaxationList() ){
      System.out.println(si);
    }
    for(CDestination si: destination.getCulturalList() ){
      System.out.println(si);
    }
    scanner.close(); 
  }
}
