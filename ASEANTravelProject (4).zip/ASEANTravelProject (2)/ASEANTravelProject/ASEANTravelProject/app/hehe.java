package app;
import java.util.*;
import models.*;
import data.*;

public class TravelApp {
    private Scanner sc;
    private Map<String, Country> countries;
    private UserSession session;
    private List<Destination> userDestinations;
    
    public TravelApp() {
        sc = new Scanner(System.in);
        countries = new HashMap<String, Country>();
        session = new UserSession();
        userDestinations = new ArrayList<Destination>();
        initializeCountries();
    }
public class colorExample {
    public static final String RESET = "\u001B[0m";
    public static final String RED = "\u001B[31m";
    public static final String GREEN = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BLUE = "\u001B[34m";
    public static final String PURPLE = "\u001B[35m";
    public static final String CYAN = "\u001B[36m";
    }
    
    private void initializeCountries() {
        Country ph = new Country("Philippines", "Mabuhay! Welcome to the Philippines!");
        ph.addDestination(new NatureDestination("Banaue Rice Terraces", "Philippines", 500, 
            "ancient rice terraces and mountain hiking"));
        ph.addDestination(new NatureDestination("Chocolate Hills", "Philippines", 450, 
            "unique geological formations and scenic views"));
        ph.addDestination(new BeachDestination("Boracay", "Philippines", 800, 
            "swimming, diving, and water sports"));
        ph.addDestination(new BeachDestination("El Nido", "Philippines", 700, 
            "island hopping and snorkeling"));
        
        Country th = new Country("Thailand", "Sawasdee! Welcome to Thailand!");
        th.addDestination(new NatureDestination("Khao Sok National Park", "Thailand", 600, 
            "jungle trekking and wildlife viewing"));
        th.addDestination(new NatureDestination("Doi Inthanon", "Thailand", 550, 
            "mountain peaks and waterfalls"));
        th.addDestination(new BeachDestination("Phuket", "Thailand", 900, 
            "diving and beach relaxation"));
        th.addDestination(new BeachDestination("Koh Samui", "Thailand", 850, 
            "swimming and sunset viewing"));
        
        Country vn = new Country("Vietnam", "Xin chào! Welcome to Vietnam!");
        vn.addDestination(new NatureDestination("Ha Long Bay", "Vietnam", 700, 
            "limestone karsts and cave exploration"));
        vn.addDestination(new NatureDestination("Sapa", "Vietnam", 500, 
            "mountain trekking and terraced fields"));
        vn.addDestination(new BeachDestination("Nha Trang", "Vietnam", 600, 
            "beach activities and island tours"));
        vn.addDestination(new BeachDestination("Phu Quoc", "Vietnam", 750, 
            "swimming and water sports"));
        
        Country id = new Country("Indonesia", "Selamat datang! Welcome to Indonesia!");
        id.addDestination(new NatureDestination("Mount Bromo", "Indonesia", 650, 
            "volcano hiking and sunrise views"));
        id.addDestination(new NatureDestination("Komodo Island", "Indonesia", 900, 
            "komodo dragons and wildlife"));
        id.addDestination(new BeachDestination("Bali Beaches", "Indonesia", 800, 
            "surfing and beach clubs"));
        id.addDestination(new BeachDestination("Gili Islands", "Indonesia", 700, 
            "snorkeling and diving"));
        
        Country my = new Country("Malaysia", "Selamat datang! Welcome to Malaysia!");
        my.addDestination(new NatureDestination("Cameron Highlands", "Malaysia", 500, 
            "tea plantations and cool climate"));
        my.addDestination(new NatureDestination("Taman Negara", "Malaysia", 600, 
            "rainforest trekking and canopy walks"));
        my.addDestination(new BeachDestination("Langkawi", "Malaysia", 750, 
            "island hopping and water sports"));
        my.addDestination(new BeachDestination("Perhentian Islands", "Malaysia", 650, 
            "diving and snorkeling"));
        
        Country sg = new Country("Singapore", "Welcome to Singapore!");
        sg.addDestination(new NatureDestination("Gardens by the Bay", "Singapore", 400, 
            "futuristic gardens and skyway walks"));
        sg.addDestination(new NatureDestination("MacRitchie Reservoir", "Singapore", 300, 
            "nature trails and tree top walks"));
        sg.addDestination(new BeachDestination("Sentosa Island", "Singapore", 500, 
            "beach activities and attractions"));
        sg.addDestination(new BeachDestination("East Coast Park", "Singapore", 250, 
            "cycling and beach sports"));
        
        Country bn = new Country("Brunei", "Selamat datang! Welcome to Brunei!");
        bn.addDestination(new NatureDestination("Ulu Temburong", "Brunei", 550, 
            "pristine rainforest and canopy walks"));
        bn.addDestination(new NatureDestination("Tasek Lama", "Brunei", 300, 
            "waterfalls and jungle trails"));
        bn.addDestination(new BeachDestination("Muara Beach", "Brunei", 400, 
            "swimming and picnics"));
        bn.addDestination(new BeachDestination("Serasa Beach", "Brunei", 350, 
            "water sports and beach activities"));
        
        Country la = new Country("Laos", "Sabaidee! Welcome to Laos!");
        la.addDestination(new NatureDestination("Kuang Si Falls", "Laos", 400, 
            "stunning waterfalls and swimming"));
        la.addDestination(new NatureDestination("Plain of Jars", "Laos", 450, 
            "ancient stone jars and archaeology"));
        la.addDestination(new BeachDestination("Don Det", "Laos", 350, 
            "river activities and relaxation"));
        la.addDestination(new BeachDestination("Vang Vieng", "Laos", 500, 
            "river tubing and kayaking"));
        
        Country mm = new Country("Myanmar", "Mingalaba! Welcome to Myanmar!");
        mm.addDestination(new NatureDestination("Inle Lake", "Myanmar", 600, 
            "floating gardens and traditional villages"));
        mm.addDestination(new NatureDestination("Hkakabo Razi", "Myanmar", 800, 
            "mountain trekking and wilderness"));
        mm.addDestination(new BeachDestination("Ngapali Beach", "Myanmar", 700, 
            "pristine beaches and swimming"));
        mm.addDestination(new BeachDestination("Ngwe Saung", "Myanmar", 650, 
            "beach relaxation and seafood"));
        
        Country kh = new Country("Cambodia", "Chum reap suor! Welcome to Cambodia!");
        kh.addDestination(new NatureDestination("Cardamom Mountains", "Cambodia", 550, 
            "wildlife and jungle trekking"));
        kh.addDestination(new NatureDestination("Bokor National Park", "Cambodia", 500, 
            "mountain views and abandoned buildings"));
        kh.addDestination(new BeachDestination("Sihanoukville", "Cambodia", 600, 
            "beach life and island hopping"));
        kh.addDestination(new BeachDestination("Koh Rong", "Cambodia", 650, 
            "white sand beaches and diving"));
        
        countries.put("1", ph);
        countries.put("2", th);
        countries.put("3", vn);
        countries.put("4", id);
        countries.put("5", my);
        countries.put("6", sg);
        countries.put("7", bn);
        countries.put("8", la);
        countries.put("9", mm);
        countries.put("10", kh);
    }
    
    private void clearScreen() {
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                System.out.print("\033[H\033[2J");
        } catch (Exception e) {
            System.out.println("\n[Unable to clear screen]");
        }
    }
    
    private String createLine(String symbol, int length) {
        return symbol.repeat(length);
    }
    
    private String centerText(String text, int width) {
        int padding = (width - text.length()) / 2;
        return " ".repeat(Math.max(0, padding)) + text;
    }
    
    private boolean displayWelcomeBanner() {
        clearScreen();
        System.out.println("\n" + createLine("=", 70));
        System.out.println(createLine("=", 70));
        System.out.println(centerText("█████╗ ███████╗███████╗ █████╗ ███╗   ██╗", 70));
        System.out.println(centerText("██╔══██╗██╔════╝██╔════╝██╔══██╗████╗  ██║", 70));
        System.out.println(centerText("███████║███████╗█████╗  ███████║██╔██╗ ██║", 70));
        System.out.println(centerText("██╔══██║╚════██║██╔══╝  ██╔══██║██║╚██╗██║", 70));
        System.out.println(centerText("██║  ██║███████║███████╗██║  ██║██║ ╚████║", 70));
        System.out.println(centerText("╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝", 70));
        System.out.println();
        System.out.println(centerText("████████╗██████╗  █████╗ ██╗   ██╗███████╗██╗     ", 70));
        System.out.println(centerText("╚══██╔══╝██╔══██╗██╔══██╗██║   ██║██╔════╝██║     ", 70));
        System.out.println(centerText("   ██║   ██████╔╝███████║██║   ██║█████╗  ██║     ", 70));
        System.out.println(centerText("   ██║   ██╔══██╗██╔══██║╚██╗ ██╔╝██╔══╝  ██║     ", 70));
        System.out.println(centerText("   ██║   ██║  ██║██║  ██║ ╚████╔╝ ███████╗███████╗", 70));
        System.out.println(centerText("   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚══════╝", 70));
        System.out.println();
        System.out.println(centerText("  D E S T I N A T I O N   F I N D E R  ", 70));
        System.out.println(createLine("=", 70));
        System.out.println(createLine("=", 70));
        System.out.print("\n" + centerText("Press Enter to continue...", 70));
        sc.nextLine();
        return true;
    }
    
    public String displayMainMenu() {
        clearScreen();
        System.out.println("\n╔" + "═".repeat(68) + "╗");
        System.out.println("║" + centerText("MAIN MENU", 68) + "║");
        System.out.println("╠" + "═".repeat(68) + "╣");
        
        String[] menuItems = {
            "[1]  Looking for a travel destination",
            "[2]  Add your own destination",
            "[3]  History",
            "[4]  Exit Program"
        };
        
        for (String item : menuItems) {
            int padding = 68 - item.length() - 3;
            System.out.println("║   " + item + " ".repeat(Math.max(0, padding)) + "║");
            System.out.println("║" + " ".repeat(68) + "║");
        }
        
        System.out.println("╚" + "═".repeat(68) + "╝");
        System.out.print("\n" + centerText("Enter your choice: ", 70));
        return sc.nextLine().trim();
    }
    
    private void lookingForDestination() {
        clearScreen();
        System.out.println("\n" + createLine("─", 70));
        System.out.println(centerText("✈️  LOOKING FOR A TRAVEL DESTINATION", 70));
        System.out.println(createLine("─", 70));
        
        System.out.println("\nWhich ASEAN country are you planning to go to?");
        System.out.println("1. Philippines\n2. Thailand\n3. Vietnam\n4. Indonesia\n5. Malaysia");
        System.out.println("6. Singapore\n7. Brunei\n8. Laos\n9. Myanmar\n10. Cambodia");
        System.out.print("Enter number: ");
        
        String countryChoice = sc.nextLine().trim();
        Country selectedCountry = countries.get(countryChoice);
        
        if (selectedCountry == null) {
            System.out.println("\n" + centerText("❌ Invalid country selection.", 70));
            System.out.print("\n" + centerText("Press Enter to return to main menu...", 70));
            sc.nextLine();
            return;
        }
        
        System.out.println("\n" + selectedCountry.getGreeting());
        System.out.print("\nPress Enter to continue...");
        sc.nextLine();
        
        System.out.print("\nEnter your estimated budget ($): ");
        double budget = Double.parseDouble(sc.nextLine().trim());
        
        System.out.println("\nWhat are you interested in?");
        System.out.println("1. Nature\n2. Beach");
        System.out.print("Enter number: ");
        String interestChoice = sc.nextLine().trim();
        
        String interest = interestChoice.equals("1") ? "Nature" : "Beach";
        
        List<Destination> matching = new ArrayList<Destination>();
        for (Destination dest : selectedCountry.getDestinations()) {
            if (dest.getType().equals(interest) && dest.getBudget() <= budget) {
                matching.add(dest);
            }
        }
        
        if (matching.isEmpty()) {
            System.out.println("\n" + centerText("No destinations found within your budget and interest.", 70));
            System.out.print("\n" + centerText("Press Enter to return to main menu...", 70));
            sc.nextLine();
            return;
        }
        
        System.out.println("\n=== SUGGESTED DESTINATIONS ===");
        for (int i = 0; i < Math.min(2, matching.size()); i++) {
            System.out.println((i + 1) + ". " + matching.get(i).getDescription());
        }
        
        System.out.print("\nChoose a destination (1 or 2): ");
        int destChoice = Integer.parseInt(sc.nextLine().trim()) - 1;
        
        if (destChoice < 0 || destChoice >= Math.min(2, matching.size())) {
            System.out.println("\n" + centerText("❌ Invalid choice.", 70));
            System.out.print("\n" + centerText("Press Enter to return to main menu...", 70));
            sc.nextLine();
            return;
        }
        
        Destination chosen = matching.get(destChoice);
        session.addSearch(chosen.getName() + " - " + chosen.getCountry());
        
        System.out.print("\nWould you like to view additional details? (yes/no): ");
        String viewDetails = sc.nextLine().trim().toLowerCase();
        
        if (viewDetails.equals("yes")) {
            showDestinationDetails(chosen, selectedCountry.getName(), budget, interest);
        } else {
            generateReceipt(chosen, selectedCountry.getName(), budget, interest);
        }
    }
    
    private void showDestinationDetails(Destination dest, String country, double budget, String interest) {
        while (true) {
            clearScreen();
            System.out.println("\n=== ON-THE-GROUND KNOWLEDGE ===");
            System.out.println("1. Cultural Descriptions");
            System.out.println("2. Usual Climate/Weather");
            System.out.println("3. Cuisine");
            System.out.println("4. Main Menu");
            System.out.println("5. Terminate Program");
            System.out.print("Enter choice: ");
            
            String choice = sc.nextLine().trim();
            
            if (choice.equals("1")) {
                System.out.println("\n=== CULTURAL INFORMATION ===");
                System.out.println(dest.getCulturalInfo());
                if (!askContinue()) return;
            } else if (choice.equals("2")) {
                System.out.println("\n=== CLIMATE INFORMATION ===");
                System.out.println(dest.getClimateInfo());
                if (!askContinue()) return;
            } else if (choice.equals("3")) {
                System.out.println("\n=== CUISINE INFORMATION ===");
                System.out.println(dest.getCuisineInfo());
                if (!askContinue()) return;
            } else if (choice.equals("4")) {
                return;
            } else if (choice.equals("5")) {
                clearScreen();
                System.out.println("\n" + createLine("═", 70));
                System.out.println(centerText("✨  Thank you for using ASEAN Travel Finder!  ✨", 70));
                System.out.println(centerText("🌏  Safe travels and happy adventures!  ✈️", 70));
                System.out.println(createLine("═", 70));
                System.exit(0);
            } else {
                System.out.println("\n" + centerText("❌ Invalid choice.", 70));
            }
        }
    }
    
    private boolean askContinue() {
        System.out.print("\nDo you want to continue viewing details? (yes/no): ");
        return sc.nextLine().trim().toLowerCase().equals("yes");
    }
    
    private void generateReceipt(Destination dest, String country, double budget, String interest) {
        String receipt = "\n========== TRAVEL SUMMARY ==========\n" +
                        "Destination: " + dest.getName() + "\n" +
                        "Country: " + country + "\n" +
                        "Budget: $" + budget + "\n" +
                        "Interest: " + interest + "\n" +
                        "Estimated Cost: $" + dest.getBudget() + "\n\n" +
                        "=== TRAVEL TIPS ===\n" +
                        "- Book accommodations in advance\n" +
                        "- Check visa requirements\n" +
                        "- Get travel insurance\n" +
                        "- Respect local customs\n" +
                        "- Keep emergency contacts handy\n" +
                        "===================================";
        
        System.out.println(receipt);
        session.addReceipt(receipt);
        System.out.print("\n" + centerText("Press Enter to return to main menu...", 70));
        sc.nextLine();
    }
    
    private void addOwnDestination() {
        clearScreen();
        System.out.println("\n" + createLine("─", 70));
        System.out.println(centerText("➕  ADD YOUR OWN DESTINATION", 70));
        System.out.println(createLine("─", 70));
        
        System.out.print("\nEnter your name: ");
        String name = sc.nextLine().trim();
        
        System.out.print("Enter your nationality: ");
        String nationality = sc.nextLine().trim();
        
        session.setUserInfo(name, nationality);
        
        System.out.print("\nEnter place name: ");
        String placeName = sc.nextLine().trim();
        
        System.out.print("Enter country: ");
        String country = sc.nextLine().trim();
        
        System.out.print("Enter required budget ($): ");
        double budget = Double.parseDouble(sc.nextLine().trim());
        
        System.out.print("Enter helpful facts: ");
        String facts = sc.nextLine().trim();
        
        System.out.print("\nSave this destination? (yes/no): ");
        String save = sc.nextLine().trim().toLowerCase();
        
        if (save.equals("yes")) {
            UserDestination userDest = new UserDestination(placeName, country, budget, facts);
            userDestinations.add(userDest);
            System.out.println("\n" + centerText("✅ Destination saved successfully!", 70));
        } else {
            System.out.println("\n" + centerText("❌ Destination not saved.", 70));
        }
        
        System.out.print("\n" + centerText("Press Enter to return to main menu...", 70));
        sc.nextLine();
    }
    
    private void viewHistory() {
        clearScreen();
        System.out.println("\n" + createLine("─", 70));
        System.out.println(centerText("📜  HISTORY", 70));
        System.out.println(createLine("─", 70));
        
        System.out.println("\n1. Receipt");
        System.out.println("2. Search History");
        System.out.println("3. Delete History");
        System.out.print("Enter choice: ");
        
        String choice = sc.nextLine().trim();
        
        if (choice.equals("1")) {
            System.out.println("\n=== YOUR RECEIPTS ===");
            if (session.getReceipts().isEmpty()) {
                System.out.println("No receipts available.");
            } else {
                for (int i = 0; i < session.getReceipts().size(); i++) {
                    System.out.println("\nReceipt " + (i + 1) + ":");
                    System.out.println(session.getReceipts().get(i));
                }
            }
        } else if (choice.equals("2")) {
            System.out.println("\n=== SEARCH HISTORY ===");
            if (session.getSearchHistory().isEmpty()) {
                System.out.println("No search history.");
            } else {
                for (int i = 0; i < session.getSearchHistory().size(); i++) {
                    System.out.println((i + 1) + ". " + session.getSearchHistory().get(i));
                }
            }
        } else if (choice.equals("3")) {
            session.clearHistory();
            System.out.println("\n" + centerText("✅ History deleted successfully!", 70));
        } else {
            System.out.println("\n" + centerText("❌ Invalid choice.", 70));
        }
        
        System.out.print("\nReturn to Main Menu? (yes/no): ");
        String returnMenu = sc.nextLine().trim().toLowerCase();
        
        if (!returnMenu.equals("yes")) {
            clearScreen();
            System.out.println("\n" + createLine("═", 70));
            System.out.println(centerText("✨  Thank you for using ASEAN Travel Finder!  ✨", 70));
            System.out.println(centerText("🌏  Safe travels and happy adventures!  ✈️", 70));
            System.out.println(createLine("═", 70));
            System.exit(0);
        }
    }
    
    public boolean processChoice(String choice) {
        switch (choice) {
            case "1":
                lookingForDestination();
                return true;
            case "2":
                addOwnDestination();
                return true;
            case "3":
                viewHistory();
                return true;
            case "4":
                clearScreen();
                System.out.println("\n" + createLine("═", 70));
                System.out.println(centerText("✨  Thank you for using ASEAN Travel Finder!  ✨", 70));
                System.out.println(centerText("🌏  Safe travels and happy adventures!  ✈️", 70));
                System.out.println(createLine("═", 70));
                return false;
            default:
                System.out.println("\n" + centerText("❌  Invalid choice. Please try again.", 70));
                System.out.print("\n" + centerText("Press Enter to return to main menu...", 70));
                sc.nextLine();
                return true;
        }
    }
    
    public int run() {
        displayWelcomeBanner();
        
        boolean continueProgram = true;
        while (continueProgram) {
            String choice = displayMainMenu();
            continueProgram = processChoice(choice);
        }
        
        return 0;
    }
    
    public static void main(String[] args) {
        TravelApp app = new TravelApp();
        app.run();
    }
}